<?php
App::uses('AppModel', 'Model');
/**
 * Premio Model
 *
 */
class Premio extends AppModel {

}

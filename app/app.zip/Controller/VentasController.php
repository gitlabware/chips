<?php

App::uses('AppController', 'Controller');

class VentasController extends AppController {
  
  public $uses = array('Ventasdistribuidore','Ventascliente','Ventasproducto','User');
  public $layout = 'viva';
  
  public function distribuidores(){
    $distribuidores = $this->User->find('all',array(''));
  }
  
}
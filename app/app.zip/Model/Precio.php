<?php
App::uses('AppModel', 'Model');
/**
 * Precio Model
 *
 */
class Precio extends AppModel {

}
